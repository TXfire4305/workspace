Highlands 1.2.5 Readme

http://www.minecraftforum.net/topic/1602064-147146-forge-highlands-new-biomes-trees-and-more/

Thank you for downloading Highlands!
Description of the features of the mod and its biomes and trees can be found on the forum post.



Installation:
Client:
Download and install the latest recommended version of Minecraft Forge.
Drag and drop this .zip folder into your "mods" folder.
Run Minecraft and enjoy!
If you want to change some settings, run Minecraft once (without making a world), quit, then go to the config folder to edit the settings.

Server:
Download and install the latest recommended version of Minecraft Forge.
Drag and drop this .zip folder into your "mods" folder.
Run the server once to generate the settings file (located in config).
Change the worldtype of the server world to "HIGHLANDS" or "HIGHLANDS_LB" in the server.properties or change "Use Highlands in Default Worlds" to true in the settings.
Change any other settings you want in the server.properties and HighlandsSettings.
Run the server. You should be all set. Clients need Highlands as well to connect to the server.

Mod Compatibility:
If you are using a mod that adds mobs that does not say it is compatible with Highlands, make sure "MobModCompatibility" is enabled.
If you are using another mod that also adds biomes, enable "Use Highlands in Default Worlds" and use a Default or Large Biomes world.
If you are using a mod or texture pack that enables custom colors for biomes, some colors in Highlands will not work as intended.
	In this case, you can either disable custom colors, disable the biomes that have custom colors, or play without the Highlands colors.
If you are using a mod that disables colors such as swamp colors (Optifine) then it will also disable the Autumn Forest, Bog, Badlands, and Flying Mountains colors.
If you are using a mod that changes ore spawning for vanilla ores, it might not be compatible or might override Highlands's ore generation.  Try disabling "useOreGens".
	Mods that add new ores to the overworld are usually fully compatible.
If you are using a mod that adds things (structures, trees, etc) that generate in specific biomes, they will usually not generate in Highlands biomes (unless the mod says it's compatible).  You will have to find that vanilla biome to have those things generate.
If you get horrible lag spikes or get stuck on "converting world", disable Mountains, Ocean2, change moreOceans to 0, and disable "useGenLayers".
	This is basically a "safe mode" but it also disables many features including all sub-biomes and ocean improvements.
All other Forge mods should be compatible with Highlands. Post on the Minecraft Forum topic if you experience an error.


Please do not redistribute Highlands or use it in a publicly available modpack without my permission.  Private modpacks and modpacks used exclusively for a single public server are alright.